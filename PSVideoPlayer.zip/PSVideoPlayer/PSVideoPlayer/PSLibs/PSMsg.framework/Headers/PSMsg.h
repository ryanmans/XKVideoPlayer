//
//  PSMsg.h
//  PSMsg
//
//  Created by Ryan_Man on 16/8/11.
//  Copyright © 2016年 Ryan_Man. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PSMsg.
FOUNDATION_EXPORT double PSMsgVersionNumber;

//! Project version string for PSMsg.
FOUNDATION_EXPORT const unsigned char PSMsgVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PSMsg/PublicHeader.h>

#import <PSMsg/PSMsgCenter.h>
