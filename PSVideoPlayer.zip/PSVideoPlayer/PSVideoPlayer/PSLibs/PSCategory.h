//
//  PSCategory.h
//  PSLibs
//
//  Created by Ryan_Man on 16/8/23.
//  Copyright © 2016年 Ryan_Man. All rights reserved.
//

#ifndef PSCategory_h
#define PSCategory_h

#import "UIView+PS.h"


#endif /* PSCategory_h */
