//
//  PSVideoPlayerVolumeView.h
//  PSVideoPlayer
//
//  Created by Ryan_Man on 16/8/29.
//  Copyright © 2016年 Ryan_Man. All rights reserved.
//

#import <UIKit/UIKit.h>

static const CGFloat kVideoVolumeIndicatorViewSide = 118.0;

@interface PSVideoPlayerVolumeView : UIView

@end
