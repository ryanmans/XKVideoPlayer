//
//  PSVideoPlayerTimeIndicatorView.h
//  PSVideoPlayer
//
//  Created by Ryan_Man on 16/8/26.
//  Copyright © 2016年 Ryan_Man. All rights reserved.
//  快进、快退指示器

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, PSTimeIndicatorPlayState)
{
    PSTimeIndicatorPlayStateRewind,      // rewind
    PSTimeIndicatorPlayStateFastForward, // fast forward
};

static const CGFloat kVideoTimeIndicatorViewSide = 96;

@interface PSVideoPlayerTimeIndicatorView : UIView

@property (nonatomic, copy) NSString *labelText;
@property (nonatomic, assign) PSTimeIndicatorPlayState playState;

@end
