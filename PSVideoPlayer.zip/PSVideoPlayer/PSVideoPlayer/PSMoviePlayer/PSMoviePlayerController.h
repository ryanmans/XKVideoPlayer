//
//  PSMoviePlayerController.h
//  PSVideoPlayer
//
//  Created by Ryan_Man on 16/8/26.
//  Copyright © 2016年 Ryan_Man. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

#import "PSVideo.h"

#define KPSVideoPlayer_OriginalWidth  MIN([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)
#define KPSVideoPlayer_OriginalHeight (KPSVideoPlayer_OriginalWidth * (11.0 / 16.0))

@interface PSMoviePlayerController : MPMoviePlayerController

@property (nonatomic,assign)CGRect frame;

@property (nonatomic,strong)PSVideo * video;

/// 竖屏模式下点击返回
@property (nonatomic, copy) void(^videoPlayerGoBackBlock)();
/// 将要切换到竖屏模式
@property (nonatomic, copy) void(^videoPlayerWillChangeToOriginalScreenModeBlock)();
/// 将要切换到全屏模式
@property (nonatomic, copy) void(^videoPlayerWillChangeToFullScreenModeBlock)();


- (instancetype)initWithFrame:(CGRect)frame;

- (void)showInView:(UIView*)superView;

@end
