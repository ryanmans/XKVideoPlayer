//
//  PSVideoPlayerBrightnessView.h
//  PSVideoPlayer
//
//  Created by Ryan_Man on 16/8/26.
//  Copyright © 2016年 Ryan_Man. All rights reserved.
//  亮度指示器

#import <UIKit/UIKit.h>

static const CGFloat kVideoBrightnessIndicatorViewSide = 118.0;

@interface PSVideoPlayerBrightnessView : UIView

@end
