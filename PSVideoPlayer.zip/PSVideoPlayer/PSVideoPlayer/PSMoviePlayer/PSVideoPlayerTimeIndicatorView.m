//
//  PSVideoPlayerTimeIndicatorView.m
//  PSVideoPlayer
//
//  Created by Ryan_Man on 16/8/26.
//  Copyright © 2016年 Ryan_Man. All rights reserved.
//

#import "PSVideoPlayerTimeIndicatorView.h"
#import "PSVideoPlayerControlView.h"


static const CGFloat kViewSpacing = 15.0;
static const CGFloat kTimeIndicatorAutoFadeOutTimeInterval = 1.0;

@interface PSVideoPlayerTimeIndicatorView ()
@property (nonatomic,strong)UIImageView * arrowImageView;
@property (nonatomic,strong)UILabel * timeLabel;
@end

@implementation PSVideoPlayerTimeIndicatorView
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.hidden = YES;
        
        self.layer.masksToBounds = YES;
        self.layer.cornerRadius = 5.0f;
        
        self.backgroundColor = RGBA(0, 0, 0, 0.3);
        
//方向
        CGFloat margin = (kVideoTimeIndicatorViewSide - 24 - 12 - kViewSpacing) / 2;
        _arrowImageView = [[UIImageView alloc] initWithFrame:CGRectMake((kVideoTimeIndicatorViewSide - 44) / 2, margin, 44, 24)];
        [self addSubview:_arrowImageView];
        
//时间
        _timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, margin + 24 + kViewSpacing, kVideoTimeIndicatorViewSide, 12)];
        _timeLabel.textColor = [UIColor whiteColor];
        _timeLabel.backgroundColor = [UIColor clearColor];
        _timeLabel.font = [UIFont systemFontOfSize:12];
        _timeLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_timeLabel];

    }
    return self;
}

- (void)setLabelText:(NSString *)labelText
{
    _labelText = labelText;
    
    self.hidden = NO;
    
    self.timeLabel.text = _labelText;
    
    //防止重叠显示
    
    if (self.superview.accessibilityIdentifier)
    {
        PSVideoPlayerControlView * videoPlayerControl = (PSVideoPlayerControlView*)self.superview;
        
        videoPlayerControl.brightnessIndicatorView.hidden = YES;
        videoPlayerControl.volumeIndicatorView.hidden = YES;
    }
    else
    {
        self.superview.accessibilityIdentifier = @"";
    }
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(animateHide) object:nil];
    [self performSelector:@selector(animateHide) withObject:nil afterDelay:kTimeIndicatorAutoFadeOutTimeInterval];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    if (self.playState == PSTimeIndicatorPlayStateRewind) {
        [self.arrowImageView setImage:[UIImage imageNamed:@"zx-video-player-rewind"]];
    } else {
        [self.arrowImageView setImage:[UIImage imageNamed:@"zx-video-player-fastForward"]];
    }
}


#pragma mark - animation -
- (void)animateHide
{
    [UIView animateWithDuration:0.3f animations:^{
        self.alpha = 0;
    } completion:^(BOOL finished) {
        
        self.hidden = YES;
        
        self.alpha = 1;
        
        self.superview.accessibilityIdentifier = nil;
        
    }];
}




@end
