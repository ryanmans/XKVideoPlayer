//
//  PSMovieViewController.m
//  PSVideoPlayer
//
//  Created by Ryan_Man on 16/8/26.
//  Copyright © 2016年 Ryan_Man. All rights reserved.
//

#import "PSMovieViewController.h"
#import "PSMoviePlayerController.h"
#import "PSVideo.h"

#import <AVFoundation/AVFoundation.h>

@interface PSMovieViewController ()
@property (nonatomic,strong)PSMoviePlayerController * moviePlayerVC;
@end

@implementation PSMovieViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    
    self.view.backgroundColor = [UIColor clearColor];
    
    self.title = self.video.title;
    
    [self playVideo];
}

- (void)playVideo
{
    if (!self.moviePlayerVC)
    {
        
        WeakSelf(ws);
        self.moviePlayerVC = [[PSMoviePlayerController alloc] initWithFrame:CGRectMake(0, 0, KPSVideoPlayer_OriginalWidth, KPSVideoPlayer_OriginalHeight)];
       
        self.moviePlayerVC.videoPlayerGoBackBlock = ^()
        {
            
            [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
            
            [ws.navigationController popViewControllerAnimated:YES];
            [ws.navigationController setNavigationBarHidden:NO animated:YES];
            
            [[NSUserDefaults standardUserDefaults] setObject:@0 forKey:@"ZXVideoPlayer_DidLockScreen"];

            
            ws.moviePlayerVC = nil;
            [ws.navigationController popViewControllerAnimated:YES];
            

        };
        
        self.moviePlayerVC.videoPlayerWillChangeToOriginalScreenModeBlock = ^()
        {
            NSLog(@"切换为竖屏模式");

        };
        
        self.moviePlayerVC.videoPlayerWillChangeToFullScreenModeBlock = ^()
        {
            PSLog(@"切换为全屏模式");
        };
        
        [self.moviePlayerVC showInView:self.view];
    }
    
    self.moviePlayerVC.video = self.video;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
