//
//  PSVideoPlayerControlView.h
//  PSVideoPlayer
//
//  Created by Ryan_Man on 16/8/26.
//  Copyright © 2016年 Ryan_Man. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PSVideoPlayerTimeIndicatorView.h"
#import "PSVideoPlayerBrightnessView.h"
#import "PSVideoPlayerVolumeView.h"
#import "PSVideoPlayerBatteryView.h"


#define KPSPlayerControlViewHideNotification @"ZXPlayerControlViewHideNotification"

@class PSVideoPlayerControlView;
@protocol PSVideoPlayerControlDelegate <NSObject>

@optional
- (void)videoPlayerControlDidTapped:(PSVideoPlayerControlView*)videoPlayer;

@end


@interface PSVideoPlayerControlView : UIView

@property(nonatomic,weak)id<PSVideoPlayerControlDelegate>delegate;

@property (nonatomic, strong, readonly) UIView *topBar;
@property (nonatomic, strong, readonly) UIView *bottomBar;
@property (nonatomic, strong, readonly) UIButton *playButton;
@property (nonatomic, strong, readonly) UIButton *pauseButton;
@property (nonatomic, strong, readonly) UIButton *fullScreenButton;
@property (nonatomic, strong, readonly) UIButton *shrinkScreenButton;
@property (nonatomic, strong, readonly) UISlider *progressSlider;
@property (nonatomic, strong, readonly) UILabel *timeLabel;
@property (nonatomic, strong, readonly) UIActivityIndicatorView *indicatorView;

@property (nonatomic, assign, readonly) BOOL isBarShowing;
/// 返回按钮
@property (nonatomic, strong, readwrite) UIButton *backButton;
/// 屏幕锁定按钮
@property (nonatomic, strong, readwrite) UIButton *lockButton;
/// 缓冲进度条
@property (nonatomic, strong, readwrite) UIProgressView *bufferProgressView;


/// 快进、快退指示器
@property (nonatomic, strong, readwrite) PSVideoPlayerTimeIndicatorView *timeIndicatorView;
/// 亮度指示器
@property (nonatomic, strong, readwrite) PSVideoPlayerBrightnessView *brightnessIndicatorView;
/// 音量指示器
@property (nonatomic, strong, readwrite) PSVideoPlayerVolumeView *volumeIndicatorView;
/// 电池条
@property (nonatomic, strong, readwrite) PSVideoPlayerBatteryView *batteryView;
/// 标题
@property (nonatomic, strong, readwrite) UILabel *titleLabel;


- (void)animateHide;
- (void)animateShow;
- (void)autoFadeOutControlBar;
- (void)cancelAutoFadeOutControlBar;
@end
