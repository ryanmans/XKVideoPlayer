//
//  PSVideoPlayerBatteryView.h
//  PSVideoPlayer
//
//  Created by Ryan_Man on 16/8/29.
//  Copyright © 2016年 Ryan_Man. All rights reserved.
//

#import <UIKit/UIKit.h>

static const CGFloat kVideoBatteryViewWidth  = 30.0;
static const CGFloat kVideoBatteryViewHeight = 12.0;

@interface PSVideoPlayerBatteryView : UIView

/// 设备电量
@property (nonatomic, assign) CGFloat batteryLevel;

@end
