//
//  PSAVPlayerViewController.h
//  PSVideoPlayer
//
//  Created by Ryan_Man on 16/8/30.
//  Copyright © 2016年 Ryan_Man. All rights reserved.
//

#import <UIKit/UIKit.h>
@class PSVideo;

@interface PSAVPlayerViewController : UIViewController
@property (nonatomic,strong)PSVideo * video;

@end
