//
//  PSPlayerView.h
//  PSVideoPlayer
//
//  Created by Ryan_Man on 16/8/30.
//  Copyright © 2016年 Ryan_Man. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

#import "PSVideo.h"

@interface PSPlayerView : UIView
@property (nonatomic,strong,readonly)AVPlayer * player;
@property (nonatomic,strong,readonly)PSVideo * video;

@property (nonatomic,copy)void (^onPlayerStatusBlock)(NSString * keyPath ,AVPlayerItem * playerItem);

@property (nonatomic,copy)void (^onplayerDidEndBlock)(NSNotification * noti);

- (void)reloadData:(PSVideo*)video;

- (void)volumeSet:(CGFloat)value;

@end
