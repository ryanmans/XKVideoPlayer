//
//  PSAVPlayerControl.m
//  PSVideoPlayer
//
//  Created by Ryan_Man on 16/8/30.
//  Copyright © 2016年 Ryan_Man. All rights reserved.
//

#import "PSAVPlayerControl.h"
#import "PSPlayerView.h"
#import "PSVideoPlayerControlView.h"

#import "PSAVPlayerControlView.h"

#import <MediaPlayer/MediaPlayer.h>

typedef NS_ENUM(NSInteger,PSPanDirection)
{
    PSPanDirectionHorizontal, // 横向移动
    PSPanDirectionVertical,   // 纵向移动
};

@interface PSAVPlayerControl ()<PSPlayerControlDelegate,UIGestureRecognizerDelegate>
{
    
    CGRect _originalFrame;
    
    CGFloat _volumeValue;
    
}
@property (nonatomic,strong)id playbackTimeObserver;

@property (nonatomic,strong)PSAVPlayerControlView * videoControl;

@property (nonatomic,strong)PSPlayerView * playerView;

// 设备方向
@property (nonatomic, assign, readonly, getter=getDeviceOrientation) UIDeviceOrientation deviceOrientation;

// 是否已经全屏模式
@property (nonatomic, assign) BOOL isFullscreenMode;

// 是否锁定
@property (nonatomic, assign,readonly,getter= isLocked) BOOL isLocked;

// 是否在调节音量
@property (nonatomic, assign) BOOL isVolumeAdjust;


// pan手势移动方向
@property (nonatomic, assign) PSPanDirection panDirection;

// 快进退的总时长
@property (nonatomic,assign)CGFloat sumTime;

@property (nonatomic,strong)UISlider  * volumeViewSlider;

@end

@implementation PSAVPlayerControl

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = YES;
        
        _originalFrame = frame;
        
        WeakSelf(ws);
        
        //播放器
        self.playerView = NewClass(PSPlayerView);
        self.playerView.backgroundColor = [UIColor blackColor];
        self.playerView.frame = self.bounds;
        self.playerView.onPlayerStatusBlock = ^(NSString * keyPath,AVPlayerItem * playerItem)
        {
            [ws observeValueForKeyPath:keyPath withPlayerItem:playerItem];
        };
        
        self.playerView.onplayerDidEndBlock = ^ (NSNotification * noti)
        {
            [ws videoPlayDidEnd:noti];
        };
        
        [self addSubview:self.playerView];
        
        
        //初始化控件菜单视图
        self.videoControl = NewClass(PSAVPlayerControlView);
        self.videoControl.delegate = self;
        self.videoControl.frame = self.bounds;
        [self addSubview:self.videoControl];
        
        //添加滑动手势 (快进 后退，调节音量 ，亮度)
        UIPanGestureRecognizer * pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panDirection:)];
        pan.delegate = self;
        [self.videoControl addGestureRecognizer:pan];
        
        [self  configVolume];
        
        //设置监听设备旋转的通知
        [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
        ps_AddPost(self, @selector(onDeviceOrientationDidChange), UIDeviceOrientationDidChangeNotification);
        
    }
    return self;
}

- (void)configVolume
{
    MPVolumeView *volumeView = [[MPVolumeView alloc] init];
    volumeView.center = CGPointMake(-1000, 0);
    [self addSubview:volumeView];
    
    _volumeViewSlider = nil;
    for (UIView *view in [volumeView subviews]){
        if ([view.class.description isEqualToString:@"MPVolumeSlider"]){
            _volumeViewSlider = (UISlider *)view;
            break;
        }
    }
    
    // 使用这个category的应用不会随着手机静音键打开而静音，可在手机静音下播放声音
//    NSError *error = nil;
//    BOOL success = [[AVAudioSession sharedInstance] setCategory: AVAudioSessionCategoryPlayback error: &error];
//    
//    if (!success) {/* error */}
//    
//    // 监听耳机插入和拔掉通知
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(audioRouteChangeListenerCallback:) name:AVAudioSessionRouteChangeNotification object:nil];
}

- (void)dealloc
{
    
    [self.playerView.player removeTimeObserver:self.playbackTimeObserver];

    self.playbackTimeObserver = nil;
    self.playerView = nil;
    self.videoControl = nil;
}

- (void)setVideo:(PSVideo *)video
{
    _video = video;
    [self.playerView reloadData:self.video];
}

#pragma mark - 播放器状态监听 -
- (void)observeValueForKeyPath:(NSString *)keyPath withPlayerItem:(AVPlayerItem*)playerItem
{
    if (playerItem == nil) return;
    
    if (IsSameString(keyPath, @"status"))
    {
        if (playerItem.status == AVPlayerStatusReadyToPlay)
        {
            PSLog(@"status --- AVPlayerStatusReadyToPlay");
            
            //获取视频总时长
            CMTime duration = playerItem.duration;
            
            //转化成秒
            CGFloat totalSecond = duration.value / playerItem.duration.timescale;
        
            self.videoControl.totalSecond = totalSecond; //CMTimeGetSeconds(duration);
            
            [self monitoringPlayBack:playerItem];
            
        }
        else if (playerItem.status == AVPlayerStatusFailed)
        {
            PSLog(@"AVPlayerStatusFailed");
        }
    }
    else if (IsSameString(keyPath, @"loadedTimeRanges"))
    {
        //计算缓冲进度
        NSTimeInterval timeInterval = [self availableDuration];
        
        CMTime duration = playerItem.duration;
        
        CGFloat totalDuration = CMTimeGetSeconds(duration);
        
        self.videoControl.bufferSecond = timeInterval / totalDuration;
    }
}

//视频播放结束
- (void)videoPlayDidEnd:(NSNotification*)noti
{
    
    WeakSelf(ws);
    [self.playerView.player seekToTime:kCMTimeZero completionHandler:^(BOOL finished) {
      
        [ws.videoControl playerControlDidEndPlayVideo];
        
    }];
}

//计算缓冲进度
- (NSTimeInterval)availableDuration
{
    NSArray * loadTimeRanges = [[self.playerView.player currentItem] loadedTimeRanges];
    
    CMTimeRange timeRange = [loadTimeRanges.firstObject CMTimeRangeValue];// 获取缓冲区域
    
    float startSeconds = CMTimeGetSeconds(timeRange.start);
    
    float durationSeconds = CMTimeGetSeconds(timeRange.duration);
    
    NSTimeInterval result = startSeconds + durationSeconds;// 计算缓冲总进度
    
    return result;
}

//用于监听每秒的状态
- (void)monitoringPlayBack:(AVPlayerItem*)playerItem
{
    
    WeakSelf(ws);
  self.playbackTimeObserver =  [self.playerView.player addPeriodicTimeObserverForInterval:CMTimeMake(1, 1) queue:NULL usingBlock:^(CMTime time) {
        
         CGFloat currentSecond = playerItem.currentTime.value/playerItem.currentTime.timescale;// 计算当前在第几秒

         ws.videoControl.currentSecond = currentSecond;
    }];
}

#pragma mark - onDeviceOrientationDidChange -
- (UIDeviceOrientation)getDeviceOrientation
{
    return [UIDevice currentDevice].orientation;
}

- (BOOL)isLocked
{
    return self.videoControl.isLocked;
}

/// 设备旋转方向改变
- (void)onDeviceOrientationDidChange
{
    UIDeviceOrientation  orientation = self.getDeviceOrientation;
    
    if (!self.isLocked)
    {
        switch (orientation) {
            case UIDeviceOrientationPortrait: {           // Device oriented vertically, home button on the bottom
                NSLog(@"home键在 下");
                [self restoreOriginalScreen];
            }
                break;
            case UIDeviceOrientationPortraitUpsideDown: { // Device oriented vertically, home button on the top
                NSLog(@"home键在 上");
            }
                break;
            case UIDeviceOrientationLandscapeLeft: {      // Device oriented horizontally, home button on the right
                NSLog(@"home键在 右");
                [self changeToFullScreenForOrientation:UIDeviceOrientationLandscapeLeft];
            }
                break;
            case UIDeviceOrientationLandscapeRight: {     // Device oriented horizontally, home button on the left
                NSLog(@"home键在 左");
                [self changeToFullScreenForOrientation:UIDeviceOrientationLandscapeRight];
            }
                break;
                
            default:
                break;
        }
    }
}

/// 切换到全屏模式
- (void)changeToFullScreenForOrientation:(UIDeviceOrientation)orientation
{
    if (self.isFullscreenMode) return;
    
    if (self.videoControl.isBarShowing) {
        [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationFade];
    } else {
        [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationFade];
    }
    
    if (self.onPlayerControlWillChangeToFullScreenModeBlock) {
        self.onPlayerControlWillChangeToFullScreenModeBlock();
    }
    
    self.frame = [UIScreen mainScreen].bounds;
    
    self.isFullscreenMode = YES;

}

/// 切换到竖屏模式
- (void)restoreOriginalScreen
{
    if (!self.isFullscreenMode) return;
    
    if ([UIApplication sharedApplication].statusBarHidden) {
        [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationFade];
    }
    if (self.onPlayerControlWillChangeToOriginalScreenModeBlock) {
        self.onPlayerControlWillChangeToOriginalScreenModeBlock();
    }
    
    self.frame = _originalFrame;
    
    self.isFullscreenMode = NO;
    
}

/// 手动切换设备方向
- (void)changeToOrientation:(UIDeviceOrientation)orientation
{
    if ([[UIDevice currentDevice] respondsToSelector:@selector(setOrientation:)])
    {
        SEL selector = NSSelectorFromString(@"setOrientation:");
        NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:[UIDevice instanceMethodSignatureForSelector:selector]];
        [invocation setSelector:selector];
        [invocation setTarget:[UIDevice currentDevice]];
        int val = orientation;
        [invocation setArgument:&val atIndex:2];
        [invocation invoke];
    }
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    
    self.playerView.frame = self.bounds;
    
    self.videoControl.frame = self.bounds;
    [self.videoControl setNeedsLayout];
}


#pragma mark - UIGestureRecognizerDelegate -
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    //触控点 是否在detial区域，而且必须没有被锁屏
    if (IsSameString(touch.view.accessibilityIdentifier, @"PSPlayerControlDetatilView") && self.isLocked == NO)
    {
        return YES;
    }
    return NO;
}

//触发手势
- (void)panDirection:(UIPanGestureRecognizer*)aPan
{
    //translationInView： 该方法返回在横坐标上、纵坐标上拖动了多少像素
    // velocityInView：在指定坐标系统中pan gesture拖动的速度

    CGPoint locationPoint = [aPan locationInView:self.videoControl];
    CGPoint veloctyPoint = [aPan velocityInView:self.videoControl];
    

    switch (aPan.state)
    {
        case UIGestureRecognizerStateBegan: //手势开始时
        {
            //去绝对值
            CGFloat x = fabs(veloctyPoint.x);
            CGFloat y = fabs(veloctyPoint.y);
        
            if (x > y) //水平移动
            {
                self.panDirection = PSPanDirectionHorizontal;
                
                self.sumTime = self.videoControl.currentSecond; //sumTime 初值
                
                //暂停播放
                [self  pauseVideo];
            }
            else if (x < y) //垂直移动
            {
                self.panDirection = PSPanDirectionVertical;
                if (locationPoint.x > self.videoControl.width / 2)
                {
                    //音量调节
                    self.isVolumeAdjust = YES;
                    
                }else
                {
                    //亮度调节
                    self.isVolumeAdjust = NO;
                }
            }
        }
        break;
            
        case UIGestureRecognizerStateChanged://正在移动
        {
            switch (self.panDirection) {
                case PSPanDirectionHorizontal:
                {
                    [self horizontalMoved:veloctyPoint.x];
                }
                break;
                case PSPanDirectionVertical:
                {
                    [self verticalMoved:veloctyPoint.y];
                }
                break;
                default:
                    break;
            }
        }
        break;
            
        case UIGestureRecognizerStateEnded://手势结束
        {
            switch (self.panDirection) {
                case PSPanDirectionHorizontal:
                {

                    CMTime changedTime = CMTimeMakeWithSeconds(self.sumTime, 1);
                    
                    [self.playerView.player seekToTime:changedTime completionHandler:^(BOOL finished) {
                        
                        [self.videoControl reloadtimePlayLabel:self.sumTime state:NO];
                        //开始播放
                        [self playVideo];
                    }];
                    
                }
                break;
                case PSPanDirectionVertical:
                {
                }
                break;
                default:
                    break;
            }
        }
        break;
        default:
            break;
    }

}

//pan 水平移动
- (void)horizontalMoved:(CGFloat)value
{
    self.sumTime += value / 200;
    
    //数据容错
    if (self.sumTime > self.videoControl.totalSecond) {
        self.sumTime = self.videoControl.totalSecond;
    }
    else if (self.sumTime < 0)
    {
        self.sumTime = 0;
    }
    
    //视频 及 视图 数据刷新
    
    // 播放进度更新
    [self.videoControl reloadtimePlayLabel:self.sumTime state:YES];
    
    // 快进or后退 状态调整
    PSTimeIndicatorPlayState playState = PSTimeIndicatorPlayStateRewind;
    
    if (value < 0) { // left
        playState = PSTimeIndicatorPlayStateRewind;
    } else if (value > 0) { // right
        playState = PSTimeIndicatorPlayStateFastForward;
    }
    
    if (self.videoControl.timePlayState != playState) {
        if (value < 0) { // left
            PSLog(@"------fast rewind");
            self.videoControl.timePlayState = PSTimeIndicatorPlayStateRewind;
        } else if (value > 0) { // right
            PSLog(@"------fast forward");
            self.videoControl.timePlayState = PSTimeIndicatorPlayStateFastForward;
        }
    }
}

//pan 垂直移动
- (void)verticalMoved:(CGFloat)value
{
    
    if (self.isVolumeAdjust) {
        
        //调节系统音量
        _volumeValue -= value / 10000;
        
        //音量在0 － 1区间取值
        if (_volumeValue > 1.0)_volumeValue = 1.0f;
        else if (_volumeValue <0.0)_volumeValue = 0.0f;
        
        ps_Post(@"AVSetting_PlayerControlVolume",[NSNumber numberWithFloat:_volumeValue]);
        
        [self.playerView volumeSet:_volumeValue];
        
        NSLog(@"setVolume---%f",_volumeValue);

    }
    else
    {
        //亮度
        [UIScreen mainScreen].brightness -= value / 10000;

    }
    
}

#pragma mark - PSPlayerControlDelegate -
- (void)playerControlView:(PSAVPlayerControlView *)playerControl withClickState:(PSPlayerControlClickState)state
{
    
    if (state == PSPlayerControlClickState_Back)
    {
    }
    else if (state == PSPlayerControlClickState_Lock)
    {
        
        
    }
    else if (state == PSPlayerControlClickState_UnLock)
    {
        
        
    }

    else if (state == PSPlayerControlClickState_Play)
    {
        [self playVideo];
    }

    else if (state == PSPlayerControlClickState_Pause)
    {
        [self  pauseVideo];
    }
    else if (state == PSPlayerControlClickState_FullScreen)
    {

        [self  fullScreenButtonClick];
    }
    else if (state == PSPlayerControlClickState_ShrinkScreen)
    {
        [self shrinkScreenButtonClick];
        
    }
    else if (state == PSPlayerControlClickState_SliderTouchBegan)
    {
        [self progressSliderTouchBegan];
        
    }
    else if (state == PSPlayerControlClickState_SliderTouchChangeValue)
    {
        [self progressSliderValueChanged];

        
    }
    else if (state == PSPlayerControlClickState_SliderTouchEnd)
    {
        [self progressSliderTouchEnded];
    }
}

//点击播放视频
- (void)playVideo
{
    if (self.video == nil || self.video.playUrl.length == 0) return;
    
    [self.videoControl playerControlDidPlayVideo];
    
    [self.playerView.player play];
}

//点击暂停视频
- (void)pauseVideo
{
    [self.playerView.player pause];
    
    [self.videoControl playerControlDidPauseVideo];
}

// slider 按下事件
- (void)progressSliderTouchBegan
{
    [self pauseVideo];
}

// slider value changed
- (void)progressSliderValueChanged
{
    CMTime changedTime = CMTimeMakeWithSeconds(self.videoControl.changeValue, 1);
    
    CGFloat changeSecond = changedTime.value/changedTime.timescale;// 计算当前在第几秒
    
    self.videoControl.currentSecond = changeSecond;
}

/// slider 松开事件
- (void)progressSliderTouchEnded
{
    CMTime changedTime = CMTimeMakeWithSeconds(self.videoControl.changeValue, 1);
    
    WeakSelf(ws);
    [self.playerView.player seekToTime:changedTime completionHandler:^(BOOL finished) {
        
        [ws playVideo];
        
    }];
}

// 全屏按钮点击
- (void)fullScreenButtonClick
{
    if (self.isFullscreenMode) return;

    [self changeToOrientation:UIDeviceOrientationLandscapeLeft];
    
}

/// 返回竖屏按钮点击
- (void)shrinkScreenButtonClick
{
    if (!self.isFullscreenMode) return;
    
    [self changeToOrientation:UIDeviceOrientationPortrait];
    
}



@end
