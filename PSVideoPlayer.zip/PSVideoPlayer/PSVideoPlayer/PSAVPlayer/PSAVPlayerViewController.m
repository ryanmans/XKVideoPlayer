//
//  PSAVPlayerViewController.m
//  PSVideoPlayer
//
//  Created by Ryan_Man on 16/8/30.
//  Copyright © 2016年 Ryan_Man. All rights reserved.
//

#import "PSAVPlayerViewController.h"
#import "PSAVPlayerControl.h"
@interface PSAVPlayerViewController ()<UITableViewDataSource,UITableViewDelegate>


@property (nonatomic,strong)NSMutableArray * aaa;

@property (nonatomic,strong)PSAVPlayerControl * playerControl;
@property (nonatomic,strong)UITableView * displayTableView;

@end

@implementation PSAVPlayerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    
    self.view.backgroundColor = [UIColor clearColor];
    
    self.title = self.video.title;
    
    [self playVideo];
}

- (void)playVideo
{
    
    WeakSelf(ws);
    self.playerControl = [[PSAVPlayerControl alloc] initWithFrame:CGRectMake(0, 0, KScreen_Width, 200)];
    self.playerControl.onPlayerControlWillChangeToOriginalScreenModeBlock = ^()
    {
//        [ws.playerControl removeFromSuperview];
//        
//        
//        ws.displayTableView.hidden = NO;
//        ws.displayTableView.tableHeaderView = (PSAVPlayerControl*)ws.aaa.firstObject;
    };
    self.playerControl.onPlayerControlWillChangeToFullScreenModeBlock = ^()
    {
        
//        ws.displayTableView.hidden = YES;
//        
//        [ws.view addSubview:ws.playerControl];
    };
    
//    _aaa = [NSMutableArray arrayWithCapacity:10];
//    
//    [_aaa addObject:self.playerControl];
//    
//    self.displayTableView.tableHeaderView = self.playerControl;
//    [self.view addSubview:self.displayTableView];
    
    
     [self.view addSubview:self.playerControl];
    self.playerControl.video = self.video;
    
}


- (UITableView*)displayTableView
{
    if (!_displayTableView) {
        _displayTableView  = [[UITableView alloc] initWithFrame:self.view.bounds style:(UITableViewStylePlain)];
        _displayTableView.delegate = self;
        _displayTableView.dataSource = self;
        _displayTableView.showsVerticalScrollIndicator = NO;
    }
    return _displayTableView;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 20;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return HalfF(100);
}
- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * cellIdentity = @"PSInfoViewController";
    
    UITableViewCell * tableViewCell = [tableView dequeueReusableCellWithIdentifier:cellIdentity];
    if (!tableViewCell) {
        tableViewCell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:cellIdentity];
    }
    tableViewCell.textLabel.text = @"图片下拉放大，导航上拉渐变";
    return tableViewCell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
